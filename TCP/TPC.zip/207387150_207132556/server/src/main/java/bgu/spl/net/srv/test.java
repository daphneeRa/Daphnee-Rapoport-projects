package bgu.spl.net.srv;


import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class test {
    public static void main(String[] args) throws IOException {
        // System.out.println((3 >> 16));
        // System.out.println((byte)(3));
        // System.out.println(String.valueOf(3).getBytes(StandardCharsets.UTF_8)[0]);
        // short a = 3;
        // byte a_bytes = (byte) (a << 8);
        // System.out.println(a_bytes);
        // int blockNumber =2 ;
        // byte[] msgStart = {(byte)(blockNumber >> 8),(byte)(blockNumber & 0xff)};
        // System.out.println(msgStart);
        // System.out.println((byte)(10));
        byte[] message ={2,0};
        short opcode = (short) (((short) message[0]) << 8 | (short) (message[1]) & 0x00ff);
        System.out.println(opcode);
        byte[] message1 ={0,(byte)4d};
        short opcode1 = (short) (((short) message1[0]) << 8 | (short) (message1[1]) & 0x00ff);
        System.out.println(opcode1);

    }
}
