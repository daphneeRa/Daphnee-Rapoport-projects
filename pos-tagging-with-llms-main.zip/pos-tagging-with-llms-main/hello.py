def main():
    print("Hello from hw1!")


if __name__ == "__main__":
    main()
